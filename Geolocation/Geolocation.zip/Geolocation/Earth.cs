﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ColinBaker.Geolocation
{
	class Earth
	{
		public const int Radius = 6378137; // In metres
	}
}
