﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ColinBaker.Geolocation.Tracks.Igc
{
	public class IgcEncoder
	{
		private const int m_maxLineLength = 76;
	}
}
